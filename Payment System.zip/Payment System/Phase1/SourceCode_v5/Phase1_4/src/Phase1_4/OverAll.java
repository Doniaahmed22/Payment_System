package Phase1_4;

public class OverAll implements Discount 
{
	
	/*Take the original price.
Divide the original price by 5.
Alternatively, divide the original price by 100 and multiply it by 20.
Subtract this new number from the original one.
The number you calculated is the discounted value. */

	price=price

}

