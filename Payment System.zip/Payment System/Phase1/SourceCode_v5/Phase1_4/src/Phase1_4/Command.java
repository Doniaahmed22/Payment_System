package Phase1_4;


public interface Command {
	public Object execute();
}
