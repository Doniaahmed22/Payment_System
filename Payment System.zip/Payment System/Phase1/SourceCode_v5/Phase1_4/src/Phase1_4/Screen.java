package Phase1_4;

public class Screen {

	public static void main(String[] args) {
		FawryApplication app = new FawryApplication();
		app.open();
//		Form form = new PaymentForm();
//		form.open();

	}

}
