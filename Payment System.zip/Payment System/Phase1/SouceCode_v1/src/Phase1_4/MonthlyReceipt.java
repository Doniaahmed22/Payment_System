package Phase1_4;

public class MonthlyReceipt extends ProviderServices {
	public MonthlyReceipt() {
		super.Name = "Monthly Receipt";
		super.form = new MonthlyReceiptForm();
	}
}
