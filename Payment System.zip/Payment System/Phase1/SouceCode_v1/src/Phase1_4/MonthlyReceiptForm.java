package Phase1_4;

public class MonthlyReceiptForm implements Form {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}
}
