package Phase1_4;

public interface Observer {
	public void Update();
}
