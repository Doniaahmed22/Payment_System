package Phase1_4;

public class MWe extends ProviderServices {
	public MWe() {
		super.Name = "Mobile Recharge Services We";
		super.form = new MWeForm();
	}
}
