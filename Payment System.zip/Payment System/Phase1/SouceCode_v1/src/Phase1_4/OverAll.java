package Phase1_4;

public class OverAll implements Discount {

}
