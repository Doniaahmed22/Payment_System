package Phase1_4;

public class IVodafoneForm  implements Form {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}
}
