package Phase1_4;

public class Specific implements Discount {

}
