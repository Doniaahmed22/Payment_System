package Phase1_4;

public interface Subject {
	public void open();
}
