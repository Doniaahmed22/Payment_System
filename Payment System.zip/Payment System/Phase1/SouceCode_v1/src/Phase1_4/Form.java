package Phase1_4;

public interface Form {
	public void open();
}
