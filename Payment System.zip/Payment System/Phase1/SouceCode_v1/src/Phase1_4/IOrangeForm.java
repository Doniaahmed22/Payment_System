package Phase1_4;

public class IOrangeForm implements Form {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}
}
