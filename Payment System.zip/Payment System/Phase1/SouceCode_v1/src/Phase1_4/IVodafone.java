package Phase1_4;

public class IVodafone extends ProviderServices {
	public IVodafone() {
		super.Name = "Internet Payment Services Vodafone";
		super.form = new IVodafoneForm();
	}
}
