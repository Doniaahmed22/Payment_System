package Phase1_4;

public class IWe extends ProviderServices {
	public IWe() {
		super.Name = "Internet Payment Services We";
		super.form = new IWeForm();
	}

}
