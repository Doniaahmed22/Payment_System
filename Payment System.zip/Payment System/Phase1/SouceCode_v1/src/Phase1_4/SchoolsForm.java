package Phase1_4;

public class SchoolsForm  implements Form {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}
}
