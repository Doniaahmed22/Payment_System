package Phase1_4;

public class SignOutController {
	public void execute() {
		FawryApplication app = new FawryApplication();
		app.open();
	}
}
