package Phase1_4;

public class QuarterReceipt extends ProviderServices {
	public QuarterReceipt() {
		super.Name = "Quarter Receipt";
		super.form = new QuarterReceiptForm();
	}
}