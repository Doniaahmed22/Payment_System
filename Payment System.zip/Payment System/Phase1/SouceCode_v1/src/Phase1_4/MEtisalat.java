package Phase1_4;

public class MEtisalat extends ProviderServices {
	public MEtisalat() {
		super.Name = "Mobile Recharge Services Etisalat";
		super.form = new MEtisalatForm();
	}
}
