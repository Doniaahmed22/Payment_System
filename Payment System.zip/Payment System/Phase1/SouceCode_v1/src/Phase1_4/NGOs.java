package Phase1_4;

public class NGOs extends ProviderServices {
	public NGOs() {
		super.Name = "Non Profiable Orangizations";
		super.form = new NGOsForm();
	}
}
