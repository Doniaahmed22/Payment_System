package Phase1_4;

public class Schools extends ProviderServices {
	public Schools() {
		super.Name = "Schools";
		super.form = new SchoolsForm();
	}

}
