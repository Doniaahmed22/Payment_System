package Phase1_4;

public class CreditCardPayment implements Payment {

}
