package Phase1_4;

public class CancerHospital extends ProviderServices {
	public CancerHospital() {
		super.Name = "Cancer Hospital";
		super.form = new CancerHospitalForm();
	}
}
