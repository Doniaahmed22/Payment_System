package Phase1_4;

public class QuarterReceiptForm  implements Form {

	@Override
	public void open() {
		// TODO Auto-generated method stub
		
	}
}
