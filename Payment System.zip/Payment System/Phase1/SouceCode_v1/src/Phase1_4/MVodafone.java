package Phase1_4;

public class MVodafone extends ProviderServices {
	public MVodafone() {
		super.Name = "Mobile Recharge Services Vodafone";
		super.form = new MVodafoneForm();
	}
}
