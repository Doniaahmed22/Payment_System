package Phase1_SW;

public interface Payment {
	public void setAmount(double x);
	public double getAmount() ;	
	public void pay(double amountOfMoney);
}
