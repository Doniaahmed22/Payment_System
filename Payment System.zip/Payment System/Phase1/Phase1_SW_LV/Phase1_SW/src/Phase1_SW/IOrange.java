package Phase1_SW;

public class IOrange extends ProviderServices {
	public IOrange() {
		super.Name = "Internet Payment Services Orange";
		super.form = new IOrangeForm();
	}
}
