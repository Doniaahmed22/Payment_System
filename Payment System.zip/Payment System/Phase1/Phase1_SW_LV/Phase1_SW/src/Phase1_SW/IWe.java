package Phase1_SW;

public class IWe extends ProviderServices {
	public IWe() {
		super.Name = "Internet Payment Services We";
		super.form = new IWeForm();
	}

}
