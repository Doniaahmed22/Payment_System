package Phase1_SW;

public class Screen {

	public static void main(String[] args) {
		FawryApplication app = new FawryApplication();
		app.open();
		
	}

}
