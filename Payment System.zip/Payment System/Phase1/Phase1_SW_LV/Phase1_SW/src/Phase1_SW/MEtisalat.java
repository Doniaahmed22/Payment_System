package Phase1_SW;

public class MEtisalat extends ProviderServices {
	public MEtisalat() {
		super.Name = "Mobile Recharge Services Etisalat";
		super.form = new MEtisalatForm();
	}
}
