package Phase1_SW;

public class ProviderServices {
	protected String Name;
	protected Form form;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public Form getForm() {
		return form;
	}

	public void setForm(Form form) {
		this.form = form;
	}

}