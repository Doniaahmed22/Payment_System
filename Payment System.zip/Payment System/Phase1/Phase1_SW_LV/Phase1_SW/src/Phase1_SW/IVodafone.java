package Phase1_SW;

public class IVodafone extends ProviderServices {
	public IVodafone() {
		super.Name = "Internet Payment Services Vodafone";
		super.form = new IVodafoneForm();
	}
}
