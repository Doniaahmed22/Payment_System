package Phase1_SW;


public class InternetPaymentServices extends Services {
	public InternetPaymentServices() {
		super.Name = "Internet Payment Services";
		listproviderservices.add(new IWe());
		listproviderservices.add(new IOrange());
		listproviderservices.add(new IVodafone());
		listproviderservices.add(new IEtisalat());

	}
}
