package Phase1_SW;

public class QuarterReceipt extends ProviderServices {
	public QuarterReceipt() {
		super.Name = "Quarter Receipt";
		super.form = new QuarterReceiptForm();
	}
}