package Phase1_SW;

public class MVodafone extends ProviderServices {
	public MVodafone() {
		super.Name = "Mobile Recharge Services Vodafone";
		super.form = new MVodafoneForm();
	}
}
