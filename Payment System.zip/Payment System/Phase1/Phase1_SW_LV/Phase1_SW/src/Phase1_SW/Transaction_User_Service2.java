package Phase1_SW;

import java.util.LinkedList;

public class Transaction_User_Service2 {
    protected LinkedList<Services> listproviderservices = new LinkedList<Services>();
}