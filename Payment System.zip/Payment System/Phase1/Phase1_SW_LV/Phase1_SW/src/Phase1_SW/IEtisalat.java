package Phase1_SW;
public class IEtisalat extends ProviderServices {
	public IEtisalat() {
		super.Name = "Internet Payment Services Etisalat";
		super.form = new IEtisalatForm();
	}

}
