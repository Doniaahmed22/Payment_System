package Phase1_SW;

public class Admin {
	private final String Username = "Hager";
	private final String Passward = "2020";

	public String getPassward() {
		return Passward;
	}

	public String getUsername() {
		return Username;
	}
}