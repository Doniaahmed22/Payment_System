package Phase1_SW;

public class MOrange extends ProviderServices {
	public MOrange() {
		super.Name = "Mobile Recharge Services Orange";
		super.form = new MOrangeForm();
	}
}
