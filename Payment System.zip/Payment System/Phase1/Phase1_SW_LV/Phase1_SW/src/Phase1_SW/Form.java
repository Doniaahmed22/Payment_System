package Phase1_SW;
public interface Form {
	public void open();
}
