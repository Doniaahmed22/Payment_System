package Phase1_SW;

public interface Observer {
	public void Update();
}
