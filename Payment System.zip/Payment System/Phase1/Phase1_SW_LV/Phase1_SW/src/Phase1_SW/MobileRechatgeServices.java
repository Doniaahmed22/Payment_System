package Phase1_SW;

public class MobileRechatgeServices extends Services {

	public MobileRechatgeServices() {
		super.Name = "Mobile Rechatge Services";
		listproviderservices.add(new MWe());
		listproviderservices.add(new MOrange());
		listproviderservices.add(new MVodafone());
		listproviderservices.add(new MEtisalat());

	}
}
