package Phase1_SW;

public class NGOs extends ProviderServices {
	public NGOs() {
		super.Name = "Non Profiable Orangizations";
		super.form = new NGOsForm();
	}
}
