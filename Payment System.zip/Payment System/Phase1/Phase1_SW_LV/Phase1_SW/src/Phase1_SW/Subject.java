package Phase1_SW;

public interface Subject {
	public void open();
}
