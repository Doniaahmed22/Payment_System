package Phase1_SW;

public interface Command {
	public Object execute();
}
