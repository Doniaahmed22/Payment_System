package Phase1_SW;

public class Schools extends ProviderServices {
	public Schools() {
		super.Name = "Schools";
		super.form = new SchoolsForm();
	}

}
