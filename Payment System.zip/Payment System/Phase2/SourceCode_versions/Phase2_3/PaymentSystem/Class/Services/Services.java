package com.Phase2.PaymentSystem.Class.Services;

import java.util.ArrayList;
import java.util.List;

import com.Phase2.PaymentSystem.Class.Discount.Discount;

public class Services {
	public String Name;
	public List<Object> provider_services = new ArrayList<>();
	public List<Discount> list_discount = new ArrayList<>();
}
