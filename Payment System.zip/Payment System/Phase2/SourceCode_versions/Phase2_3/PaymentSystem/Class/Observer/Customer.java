package com.Phase2.PaymentSystem.Class.Observer;

public class Customer {
	public String Username;
	public String Password;
	public String Email;
}
