package com.Phase2.PaymentSystem.Class.Payment;

public abstract class Payment {
	public double Amount = 0;
	public String Username;
}
