package com.Phase2.PaymentSystem.Class.Payment;

public class CreditCard extends Payment {
	public CreditCard(String Username, double Amount) {
		this.Username = Username;
		this.Amount = Amount;
	}
}
