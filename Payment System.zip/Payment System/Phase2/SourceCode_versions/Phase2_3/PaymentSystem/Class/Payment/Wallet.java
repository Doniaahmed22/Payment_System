package com.Phase2.PaymentSystem.Class.Payment;


public class Wallet extends Payment {
	public Wallet(String Username, double Amount) {
		this.Username = Username;
		this.Amount = Amount;
	}
}
