package com.Phase2.PaymentSystem.Class.Provider_Service;

public class MEtisalat implements Etisalat{
	public String Name="Mobile Recharge Service We";

}
