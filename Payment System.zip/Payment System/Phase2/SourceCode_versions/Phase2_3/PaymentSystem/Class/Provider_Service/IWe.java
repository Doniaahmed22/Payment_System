package com.Phase2.PaymentSystem.Class.Provider_Service;

public class IWe implements We{
	public String Name="Internet Payment Service We";

}
