package com.Phase2.PaymentSystem.Class.Provider_Service;

public class MVodafone implements Vodafone{
	public String Name="Mobile Recharge Service Vodafone";

}
