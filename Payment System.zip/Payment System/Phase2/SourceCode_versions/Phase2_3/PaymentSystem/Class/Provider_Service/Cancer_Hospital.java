package com.Phase2.PaymentSystem.Class.Provider_Service;

public class Cancer_Hospital {
	public String Name = "Cancer Hospital";
}
