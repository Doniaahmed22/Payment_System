package com.Phase2.PaymentSystem.Class.Provider_Service;

public interface We {

}
