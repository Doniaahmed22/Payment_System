package com.Phase2.PaymentSystem.Class.Provider_Service;

public class IOrange implements Orange{
	public String Name="Internet Payment Service Orange";

}
