package com.Phase2.PaymentSystem.Class.Provider_Service;

public class IEtisalat implements Etisalat{
	public String Name = "Internet Payment Service Etisalat";

}
