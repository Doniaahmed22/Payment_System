package com.Phase2.PaymentSystem.Class.Provider_Service;

public class Monthly_Receipt {
	public String Name="Monthly Receipt";

}
