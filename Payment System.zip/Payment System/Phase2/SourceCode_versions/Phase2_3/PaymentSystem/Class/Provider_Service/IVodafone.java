package com.Phase2.PaymentSystem.Class.Provider_Service;

public class IVodafone implements Vodafone{
	public String Name="Internet Payment Service Vodafone";

}
