package com.Phase2.PaymentSystem.Class.Provider_Service;

public class MOrange implements Orange{
	public String Name="Mobile Recharge Service Orange";

}
