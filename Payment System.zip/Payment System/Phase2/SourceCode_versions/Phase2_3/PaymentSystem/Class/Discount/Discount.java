package com.Phase2.PaymentSystem.Class.Discount;

public abstract class Discount {
	protected double discount;

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}
}
