package com.Phase2.PaymentSystem.Class.Discount;


public class Overall extends Discount {
	public Overall(double discount) {
		this.discount = discount;
	}

	public void setDiscount(double discount) {
		super.setDiscount(discount);
	}

	public double getDiscount() {
		return super.getDiscount();
	}
}
