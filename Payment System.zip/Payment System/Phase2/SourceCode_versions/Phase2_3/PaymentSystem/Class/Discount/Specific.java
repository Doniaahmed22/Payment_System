package com.Phase2.PaymentSystem.Class.Discount;


public class Specific extends Discount {
	public Specific() {
		this.discount = 10;
	}

	public double getDiscount() {
		return super.getDiscount();
	}
}
