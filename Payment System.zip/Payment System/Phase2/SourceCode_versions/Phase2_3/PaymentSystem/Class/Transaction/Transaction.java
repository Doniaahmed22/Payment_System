package com.Phase2.PaymentSystem.Class.Transaction;

public abstract class Transaction {
	public String Username;
	public double Amount;
}