package com.Phase2.PaymentSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
