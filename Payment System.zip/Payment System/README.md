# SW_20201206_20201060_20201191_20200230

Spring intializer with :
Group -> Phase2
Artifact -> PaymentSystem
Maven Project
java version 11
Packaging jar
Spring Boot 2.7.7
-----------
Eclipse IDE
Postman API
-----------
Postman link of Workspace ->
-----------
https://www.postman.com/crimson-comet-758858/workspace/phase2-sw-20201206-20201191-20201060-20200230
